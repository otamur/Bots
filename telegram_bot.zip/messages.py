# Welcome message for /start command
WELCOME_MESSAGE = """Assalomu alaykum botimizga hushkilibsiz 💎RANK🛡KIT 🗝 KEYS olmoqchi boʻlsangiz 🛠 ADMIN Dan sotib olishingiz mumkun lichka
@kamol0_0
@vvv124

Serverga kirish uchun 
⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️
AngelRIP.aternos.me
⬆️⬆️⬆️⬆️⬆️⬆️⬆️⬆️⬆️"""

# Rank prices message
RANK_PRICES = """💎RANKLAR  NARXI:

5.000 so'm  VIP 🟩
17.000 so'm  PRO 🟦
27.000 so'm  ELITE 🟪
45.000 so'm  CROW🟫
69.000 so'm  DRAGON 🟨
129.000 so'm MODERATOR 🟧
169.000 so'm ADMIN🟥
299.000 so'm BOSS ⬛️

Sotib olish uchun @vvv124 @kamol0_0"""

# Kit prices message
KIT_PRICES = """🛡KITLAR  NARXI:

5.000 so'm  VIP 🟩
10.000 so'm  PRO 🟦
20.000 so'm  ELITE 🟪
37.000 so'm  CROW🟫
49.000 so'm  DRAGON 🟨
79.000 so'm MODERATOR 🟧
99.000 so'm ADMIN🟥
139.000 so'm BOSS ⬛️

Sotib olish uchun @vvv124 @kamol0_0"""

# Keys prices message
KEYS_PRICES = """🗝 KEYSLAR  NARXI:

💎 DOTANE KEYS 39.000 soʻm
⚜ TELESMAN KEYS 27.000 soʻm
🔱 SUPER TELESMAN KEYS 37.000 soʻm
🪞 ULTRA KEYS 19.000 soʻm
🛡 KITS KEYS 29.000 soʻm

Sotib olish uchun @vvv124 @kamol0_0"""

# Admin message
ADMIN_MESSAGE = """uziz uchun 💎 RANK yaratib beramiz
RANK ni ichiga qoʻshilmaydigan pravalar
1unban
2 ban
3 unmute
4 mute
5 eco
6 gamemode
7 point 
8 phoenixc 
9 jail 
10 unjail
Mana shular qushilmiydi 💎 RANK ga
narxi 50.000 so'm yasash uchun lichga yozin 

KIMNI 1K OBUNACHILIG YOUTUBINGIZ BULSA MANGA YOSIN PASTDA LICHKAM
⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️
@vvv124
@kamol0_0

Serverga kirish uchun
⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️
ip: AngelRIP.aternos.me:32215"""
